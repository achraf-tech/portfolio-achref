import React from "react";
import { FaGithub } from "react-icons/fa";


function ServiceItem2() {
  return (
   
      <div className="services__box">
        <FaGithub className="common-icons" />
        <div className="services__box-header">Photography</div>
        <div className="services__box-p">
          It is defined as the connections "Achref ben kadaa "
        </div>
    </div>
    
  );
}

export default ServiceItem2;
