import React from 'react'; 
import { FaGithub } from "react-icons/fa";

const ServiceItem4 = () => {
    return (
        <div className="services__box">
        <FaGithub className="common-icons" />
        <div className="services__box-header">Web development</div>
        <div className="services__box-p">
          It is defined as the connections "??????????," 
        </div>
        
    </div>
    
    )
}

export default ServiceItem4
